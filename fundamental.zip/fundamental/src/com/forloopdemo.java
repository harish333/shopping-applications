package com;

public class forloopdemo {

	public static void main(String[] args) {
		int x=1;
		if(x>0||x++<10)
		{
			System.out.println("hello:"+x);
		}
		else
		{
			System.out.println("hai;"+x);
		}
		// TODO Auto-generated method stub

	}

}
