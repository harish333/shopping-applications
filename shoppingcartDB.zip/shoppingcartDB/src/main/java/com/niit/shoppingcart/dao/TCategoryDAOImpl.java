package com.niit.shoppingcart.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.model.TCategory;

@Repository("tCategoryDAO")
public class TCategoryDAOImpl implements TCategoryDAO{
	@Autowired
	private TCategory tCategory;
	@Autowired
	private SessionFactory sessionFactory;
	public TCategoryDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	public boolean save(TCategory category){
		try
		{
			sessionFactory.getCurrentSession().save(category);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		   return false;
		}
		return true;
	}
	public boolean update(TCategory category){
		try
		{
			sessionFactory.getCurrentSession().update(category.getId());
		}
		catch(Exception e)
		{
			e.printStackTrace();
              return false;
		}
		return true;
	}	
	public boolean delete(String id){
		try
		{
			sessionFactory.getCurrentSession().delete(id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
				return false;
		}
		return true;
	}
		public TCategory get(String id){
		//select*from category where id='id'
			String hql="from TCategory where id='"+id+"'";
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			List<TCategory>list=query.list();
			if(list == null||list.isEmpty())
			{
				return null;
			}
			return tCategory;
	}
	public List<TCategory> list(){
		return null;
	}

}
