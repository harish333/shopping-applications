package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.TCategory;

public interface TCategoryDAO {
//crud (create,retrieve,update,delete)operations the operations which are to be used have to declare
	public boolean save(TCategory category);
	public boolean update(TCategory category);
	public boolean delete(String id);
	//based on the id it will return the category domain
	public TCategory get(String id);
	//to get all categories
	public List<TCategory> list();
}
