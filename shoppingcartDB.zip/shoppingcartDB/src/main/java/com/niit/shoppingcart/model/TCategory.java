package com.niit.shoppingcart.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.h2.command.dml.Select;
import org.h2.command.dml.Set;
import org.springframework.stereotype.Component;

@Entity
@Table(name="Category")
@Component
public class TCategory {
          
	   private String id;
	   private String name;
	   private String description;
	   private Set product;
	   

	@OneToMany(mappedBy="category",fetch=FetchType.EAGER)
	public Select getProduct() {
		return getProduct();
	}

	public void setProduct(Set product) {
		this.product = product;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	   
}
