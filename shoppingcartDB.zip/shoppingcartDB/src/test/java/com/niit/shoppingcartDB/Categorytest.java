package com.niit.shoppingcartDB;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.model.TCategory;

public class Categorytest {

	
	public static void main(String[] args) { 
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart.dao");
		context.refresh();
		Categorytest categoryDAO = (Categorytest)context.getBean("categoryDAO");
		TCategory category = (TCategory) context.getBean("category");
		category.setId("h3");
		category.setName("hari");
		category.setDescription("hai");
		System.out.println("objects are created succefully");
	}
}
