package com.niit.shoppingcartDB;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.TCategoryDAO;
import com.niit.shoppingcart.model.TCategory;

public class CategorytTestcase {
@Autowired
AnnotationConfigApplicationContext context;
@Autowired
TCategoryDAO tcategoryDAO;
@Autowired
TCategory tcategory;
public void init(){
	context = new AnnotationConfigApplicationContext();
	context.scan("com.niit");
	context.refresh();
	tcategory = (TCategory) context.getBean("tcategory");
	tcategoryDAO = (TCategoryDAO) context.getBean("tcategoryDAO");
	}
@Test
public void createCategoryTeatcase(){
	tcategory.setId("Lap1");
	tcategory.setName("dell");
	tcategory.setDescription("dell lap2");
	Assert.assertEquals("Create Category",true,tcategoryDAO.save(tcategory));
	}
public void updateCategoryTeatcase(){
	tcategory.setId("Lap2");
	tcategory.setName("dell");
	tcategory.setDescription("dell lap2");
	Assert.assertEquals("Create Category",true,tcategoryDAO.update(tcategory));
	}


}
