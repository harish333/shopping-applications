/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Example.domain;

/**
 *
 * @author MRuser
 */
public class Employee
{

    int EmployeeID ;
    String Employeename ;
    String Employeesocialsecuritynumber ;
    double Employeesalary ;
    public void setEmployeeID(int EmployeeID) 
    {
     this.EmployeeID=EmployeeID;
    }    
    public int getEmployeeID()
    { 
    return EmployeeID;
    }
     
    public void setEmployeename(String Employeename)
    {
    this.Employeename=Employeename;
     }
    public String getEmployeename()
    {
     return Employeename;       
    }
    public void setEmployeesocialsecuritynumber(String Employeesocialsecuritynumber) 
    {
    this.Employeesocialsecuritynumber=Employeesocialsecuritynumber;
     }
    public String getEmployeesocialsecuritynumber()
    {
    return Employeesocialsecuritynumber;
    }
    public void setEmployeesalary(double Employeesalary)
    {
     this.Employeesalary=Employeesalary;
       }
    public double getEmployeesalary()
    {
        return Employeesalary;
    }

   
}
