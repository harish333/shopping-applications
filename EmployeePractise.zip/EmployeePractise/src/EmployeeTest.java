
import com.Example.domain.Employee;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MRuser
 */
public class EmployeeTest {

    
    
    public static void main(String[] args) {
        
        // TODO code application logic here
    
    Employee human = new Employee();

    
       
        human.setEmployeeID(101);
        human.setEmployeename("jane smith");
        human.setEmployeesalary(123);
        human.setEmployeesocialsecuritynumber("12305");
        int i=human.getEmployeeID();
        String j=human.getEmployeename();
        double k=human.getEmployeesalary();
        String l=human.getEmployeesocialsecuritynumber();
        System.out.println("EmployeeID is"+i);
        System.out.println("Employeename is"+j);
        System.out.println("Employee salary is"+k);
        System.out.println("Employee socialsecuritynumber"+l);
                        
    }

    
}
